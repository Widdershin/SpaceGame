Build Controls
1 (hull), 2 (engine), 3 (cockpit), 4 (thrusters), 5 (blasters) to select blocks
Left click to place
Right click to destroy
Middle click to set symmetry line

Enter to build ship
M to build debris

Ship Controls
WASD to fly ship
Space to fire
Enter to break ship
